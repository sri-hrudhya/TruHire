import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import {
  Mail,
  Phone,
  GraduationCap,
  Briefcase,
  FileText,
  Sparkles,
} from 'lucide-react';
import { candidatesApi } from '../lib/api';
import ResumePreviewModal from '../components/ResumePreviewModal';
import PageBreadcrumbs from '../components/PageBreadcrumbs';
import { useBackNavigation } from '../lib/navigation';
import { useMeta } from '../context/MetaContext';
import CommentThread from '../components/review/CommentThread';

export default function CandidateDetailPage() {
  const { id } = useParams();
  const { candidate_statuses: candidateStatuses } = useMeta();
  // Back returns to wherever the profile was opened from (Search, Requirements, Ingestion History).
  const { goBack, backLabel } = useBackNavigation('/search', 'Search');
  const [candidate, setCandidate] = useState(null);
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isResumeOpen, setIsResumeOpen] = useState(false);
  const [statusMessage, setStatusMessage] = useState(null);

  useEffect(() => {
    const loadCandidateData = async () => {
      setLoading(true);
      try {
        const [candRes, matchesRes] = await Promise.all([
          candidatesApi.get(id),
          candidatesApi.getMatches(id)
        ]);
        setCandidate(candRes.data);
        setMatches(matchesRes.data.matches || []);
      } catch (err) {
        console.error('Error loading candidate detail:', err);
      } finally {
        setLoading(false);
      }
    };
    loadCandidateData();
  }, [id]);

  const handleStatusUpdate = async (newStatus) => {
    try {
      await candidatesApi.updateStatus(id, newStatus);
      setCandidate(prev => ({ ...prev, status: newStatus }));
      setStatusMessage(`Recruitment status updated to ${newStatus}`);
      setTimeout(() => setStatusMessage(null), 3000);
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  };

  if (loading) {
    return (
      <div className="page-body" style={{ textAlign: 'center', padding: '4rem' }}>
        <Sparkles size={32} className="animate-spin" color="var(--primary)" style={{ margin: '0 auto 1rem' }} />
        <div style={{ fontSize: '1rem', fontWeight: 600 }}>Loading Candidate Dossier...</div>
      </div>
    );
  }

  if (!candidate) {
    return (
      <div className="page-body" style={{ textAlign: 'center', padding: '4rem' }}>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 700 }}>Candidate not found</h2>
        <button type="button" onClick={goBack} className="btn btn-primary" style={{ marginTop: '1rem' }}>
          Return to {backLabel}
        </button>
      </div>
    );
  }

  return (
    <div className="page-body">
      {/* Back button */}
      <PageBreadcrumbs
        onBack={goBack}
        backLabel={backLabel}
        items={[
          { label: backLabel, onClick: goBack },
          { label: candidate.candidate_name || candidate.display_id || 'Candidate' },
        ]}
      />

      {statusMessage && (
        <div className="badge-success" style={{ padding: '0.75rem 1rem', borderRadius: '8px', marginBottom: '1.5rem' }}>
          {statusMessage}
        </div>
      )}

      {/* Profile Overview Card */}
      <div className="card" style={{ marginBottom: '2rem', padding: '2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
            <div style={{
              width: '64px',
              height: '64px',
              borderRadius: '50%',
              backgroundColor: 'var(--primary-light)',
              border: '2px solid var(--primary-border)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--primary)',
              fontSize: '1.75rem',
              fontWeight: 800
            }}>
              {candidate.candidate_name.charAt(0)}
            </div>

            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
                <span
                  className="badge badge-primary"
                  style={{
                    fontSize: '0.8125rem',
                    fontFamily: 'var(--font-mono)',
                    fontWeight: 800,
                    padding: '0.25rem 0.65rem'
                  }}
                >
                  {candidate.display_id || 'TRU-CN-????'}
                </span>
                <h1 style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--text-main)', margin: 0 }}>
                  {candidate.candidate_name}
                </h1>
                <span className="badge badge-neutral">
                  Shared Talent Pool
                </span>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem', flexWrap: 'wrap', marginTop: '0.5rem', fontSize: '0.875rem', color: 'var(--text-muted)' }}>
                {candidate.email && (
                  <span style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                    <Mail size={14} /> {candidate.email}
                  </span>
                )}
                {candidate.phone && (
                  <span style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                    <Phone size={14} /> {candidate.phone}
                  </span>
                )}
                <span style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <Briefcase size={14} /> {candidate.years_experience} Years Experience
                </span>
              </div>
            </div>
          </div>

          {/* Actions: View Resume + Status Dropdown + AI Chat */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
            <button
              onClick={() => setIsResumeOpen(true)}
              className="btn btn-secondary"
              title="Preview candidate resume document"
            >
              <FileText size={16} color="var(--primary)" /> View Resume
            </button>

            <select
              value={candidate.status}
              onChange={(e) => handleStatusUpdate(e.target.value)}
              className="input-field"
              style={{
                width: 'auto',
                padding: '0.625rem 1rem',
                fontSize: '0.875rem',
                fontWeight: 600,
                backgroundColor: 'var(--bg-subtle)'
              }}
            >
              {candidateStatuses.map((st) => <option key={st} value={st}>{st}</option>)}
            </select>
          </div>
        </div>

        {/* Qualifications row */}
        <div style={{
          marginTop: '1.5rem',
          paddingTop: '1.5rem',
          borderTop: '1px solid var(--border-color)',
          display: 'grid',
          gridTemplateColumns: '1fr 2fr',
          gap: '2rem'
        }}>
          <div>
            <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-subtle)', textTransform: 'uppercase', marginBottom: '0.5rem' }}>
              Education & Credentials
            </div>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.5rem', fontSize: '0.875rem', color: 'var(--text-main)' }}>
              <GraduationCap size={18} color="var(--primary)" style={{ flexShrink: 0, marginTop: '2px' }} />
              <div>{candidate.education || 'Self-taught / Not formally specified'}</div>
            </div>
          </div>

          <div>
            <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-subtle)', textTransform: 'uppercase', marginBottom: '0.5rem' }}>
              Extracted Technical Competencies ({candidate.extracted_skills?.length || 0})
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
              {candidate.extracted_skills?.map((s, idx) => (
                <span key={idx} className="badge badge-neutral" style={{ fontSize: '0.75rem' }}>
                  {s}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Requirements Match Matrix */}
      <div className="card">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
          <div>
            <h3 style={{ fontSize: '1.125rem', fontWeight: 800, color: 'var(--text-main)' }}>
              Requirements Match Matrix
            </h3>
            <p style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
              Evaluations of this candidate against job requirements across the platform.
            </p>
          </div>
          <span className="badge badge-neutral">
            {matches.length} Evaluated Requirement(s)
          </span>
        </div>

        {matches.length > 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {matches.map((m) => {
              const badgeClass = m.match_score >= 80 ? 'badge-success' : m.match_score >= 60 ? 'badge-warning' : 'badge-neutral';
              return (
                <div
                  key={m.match_id}
                  style={{
                    padding: '1.25rem',
                    borderRadius: 'var(--radius-md)',
                    border: '1px solid var(--border-color)',
                    backgroundColor: 'var(--bg-surface)'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
                      {m.position_display_id && (
                        <span className="badge badge-primary" style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', fontWeight: 700 }}>
                          {m.position_display_id}
                        </span>
                      )}
                      <span style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-main)' }}>
                        {m.position_title}
                      </span>
                      <span className="badge badge-neutral" style={{ fontSize: '0.7rem' }}>
                        {m.is_version_current ? 'Current requirement' : 'Earlier requirement version'}
                      </span>
                    </div>

                    <span className={`badge ${badgeClass}`} style={{ fontSize: '0.8125rem', fontWeight: 800 }}>
                      {m.match_score.toFixed(1)}% Match
                    </span>
                  </div>

                  {/* Summary & Citation */}
                  {m.llm_summary && (
                    <p style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', lineHeight: 1.5, marginBottom: '0.75rem' }}>
                      {m.llm_summary}
                    </p>
                  )}

                  {m.cited_quote && (
                    <div style={{
                      padding: '0.625rem 0.875rem',
                      backgroundColor: 'var(--bg-subtle)',
                      borderRadius: '6px',
                      borderLeft: '3px solid var(--primary)',
                      fontSize: '0.75rem',
                      color: 'var(--text-muted)',
                      fontStyle: 'italic'
                    }}>
                      "{m.cited_quote}"
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-subtle)', fontSize: '0.875rem' }}>
            This candidate has not yet been scored against any active Requirements in Search.
          </div>
        )}
      </div>

      <section className="card" style={{ marginTop: '2rem', padding: '1.5rem' }}>
        <div className="section-head"><h2>Team feedback</h2></div>
        <div style={{ paddingTop: 'var(--space-4)' }}>
          <CommentThread candidateId={candidate.id} />
        </div>
      </section>

      {/* Resume Preview Modal */}
      <ResumePreviewModal
        isOpen={isResumeOpen}
        onClose={() => setIsResumeOpen(false)}
        candidate={candidate}
      />
    </div>
  );
}
